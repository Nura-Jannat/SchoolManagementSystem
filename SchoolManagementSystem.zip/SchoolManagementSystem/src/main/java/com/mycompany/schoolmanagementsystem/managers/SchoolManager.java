package com.mycompany.schoolmanagementsystem.managers;

import com.mycompany.schoolmanagementsystem.models.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SchoolManager implements Serializable {
    private List<Student> students;
    private List<Teacher> teachers;
    private List<Attendance> attendances;
    private List<Classroom> classrooms;
    private List<MarkSheet> markSheets;  // Make sure this exists
    
    public SchoolManager() {
        this.students = new ArrayList<>();
        this.teachers = new ArrayList<>();
        this.attendances = new ArrayList<>();
        this.classrooms = new ArrayList<>();
        this.markSheets = new ArrayList<>();  // Initialize the list
        
        // Add sample data
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        if (students.isEmpty()) {
            students.add(new Student("John Doe", "S001", "10-A", "555-0001"));
            students.add(new Student("Jane Smith", "S002", "10-A", "555-0002"));
            students.add(new Student("Bob Wilson", "S003", "10-B", "555-0003"));
            students.add(new Student("Alice Brown", "S004", "10-B", "555-0004"));
            students.add(new Student("Charlie Lee", "S005", "11-A", "555-0005"));
        }
        
        if (classrooms.isEmpty()) {
            classrooms.add(new Classroom("10-A"));
            classrooms.add(new Classroom("10-B"));
            classrooms.add(new Classroom("11-A"));
        }
    }
    
    // Student Management
    public void addStudent(Student student) {
        if (!checkDuplicateStudentId(student.getId())) {
            students.add(student);
            addStudentToClassroom(student);
        }
    }
    
    public void deleteStudent(String id) {
        students.removeIf(s -> s.getId().equals(id));
        for (Classroom c : classrooms) {
            c.removeStudent(id);
        }
    }
    
    public Student findStudentById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) {
                return s;
            }
        }
        return null;
    }
    
    public List<Student> searchStudents(String query) {
        return students.stream()
            .filter(s -> s.getId().toLowerCase().contains(query.toLowerCase()) ||
                        s.getName().toLowerCase().contains(query.toLowerCase()))
            .collect(Collectors.toList());
    }
    
    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }
    
    private boolean checkDuplicateStudentId(String id) {
        return students.stream().anyMatch(s -> s.getId().equals(id));
    }
    
    private void addStudentToClassroom(Student student) {
        for (Classroom c : classrooms) {
            if (c.getClassName().equals(student.getClassName())) {
                c.addStudent(student);
                break;
            }
        }
    }
    
    // Teacher Management
    public void addTeacher(Teacher teacher) {
        if (!checkDuplicateTeacherId(teacher.getId())) {
            teachers.add(teacher);
        }
    }
    
    public void deleteTeacher(String id) {
        teachers.removeIf(t -> t.getId().equals(id));
    }
    
    public Teacher findTeacherById(String id) {
        for (Teacher t : teachers) {
            if (t.getId().equals(id)) {
                return t;
            }
        }
        return null;
    }
    
    public List<Teacher> getAllTeachers() {
        return new ArrayList<>(teachers);
    }
    
    private boolean checkDuplicateTeacherId(String id) {
        return teachers.stream().anyMatch(t -> t.getId().equals(id));
    }
    
    // Attendance Management
    public void addAttendance(Attendance attendance) {
        attendances.add(attendance);
    }
    
    public List<Attendance> getAttendanceByStudent(String studentId) {
        return attendances.stream()
            .filter(a -> a.getStudentId().equals(studentId))
            .collect(Collectors.toList());
    }
    
    public List<Attendance> getAllAttendances() {
        return new ArrayList<>(attendances);
    }
    
    public double getAttendancePercentage(String studentId) {
        List<Attendance> studentAttendance = getAttendanceByStudent(studentId);
        if (studentAttendance.isEmpty()) return 0;
        
        long presentCount = studentAttendance.stream()
            .filter(a -> a.getStatus().equals("Present"))
            .count();
        
        return (presentCount * 100.0) / studentAttendance.size();
    }
    
    // MarkSheet Management - ADD THESE METHODS
    public void addMarkSheet(MarkSheet markSheet) {
        if (markSheet != null) {
            markSheets.add(markSheet);
            System.out.println("MarkSheet added for student: " + markSheet.getStudentId());
        }
    }
    
    public List<MarkSheet> getMarkSheetsByStudent(String studentId) {
        return markSheets.stream()
            .filter(m -> m.getStudentId().equals(studentId))
            .collect(Collectors.toList());
    }
    
    public List<MarkSheet> getAllMarkSheets() {
        return new ArrayList<>(markSheets);
    }
    
    public double getStudentAverage(String studentId) {
        List<MarkSheet> studentMarks = getMarkSheetsByStudent(studentId);
        if (studentMarks.isEmpty()) return 0;
        
        double total = studentMarks.stream().mapToDouble(MarkSheet::getMarks).sum();
        return total / studentMarks.size();
    }
    
    public void deleteMarkSheet(String studentId, String subject) {
        markSheets.removeIf(m -> m.getStudentId().equals(studentId) && m.getSubject().equals(subject));
    }
    
    // Classroom Management
    public void addClassroom(Classroom classroom) {
        if (!checkDuplicateClassroom(classroom.getClassName())) {
            classrooms.add(classroom);
        }
    }
    
    public Classroom findClassroom(String className) {
        for (Classroom c : classrooms) {
            if (c.getClassName().equals(className)) {
                return c;
            }
        }
        return null;
    }
    
    public List<Classroom> getAllClassrooms() {
        return new ArrayList<>(classrooms);
    }
    
    private boolean checkDuplicateClassroom(String className) {
        return classrooms.stream().anyMatch(c -> c.getClassName().equals(className));
    }
    
    // Statistics
    public int getTotalStudents() {
        return students.size();
    }
    
    public int getTotalTeachers() {
        return teachers.size();
    }
    
    public int getTotalAttendances() {
        return attendances.size();
    }
    
    public int getTotalMarkSheets() {
        return markSheets.size();
    }
}