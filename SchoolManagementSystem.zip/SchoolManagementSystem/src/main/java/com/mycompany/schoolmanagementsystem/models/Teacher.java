package com.mycompany.schoolmanagementsystem.models;

import java.io.Serializable;

public class Teacher extends Person implements Serializable {
    private String subject;
    private String phone;
    private double salary;
    
    public Teacher(String name, String id, String subject, String phone, double salary) {
        super(name, id);
        this.subject = subject;
        this.phone = phone;
        this.salary = salary;
    }
    
    @Override
    public String getInfo() {
        return "ID: " + id + " | Name: " + name + " | Subject: " + subject + " | Salary: $" + salary;
    }
    
    public String getSubject() { return subject; }
    public String getPhone() { return phone; }
    public double getSalary() { return salary; }
    
    public void setSubject(String subject) { this.subject = subject; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setSalary(double salary) { this.salary = salary; }
}
