
package com.mycompany.schoolmanagementsystem.models;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Classroom implements Serializable {
    private String className;
    private List<Student> studentList;
    
    public Classroom(String className) {
        this.className = className;
        this.studentList = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        studentList.add(student);
    }
    
    public void removeStudent(String studentId) {
        studentList.removeIf(s -> s.getId().equals(studentId));
    }
    
    public String getClassName() { return className; }
    public List<Student> getStudentList() { return studentList; }
    
    public void setClassName(String className) { this.className = className; }
    public void setStudentList(List<Student> studentList) { this.studentList = studentList; }

    public Object getName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}