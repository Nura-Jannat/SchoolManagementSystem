package com.mycompany.schoolmanagementsystem.models;

import java.io.Serializable;

public class MarkSheet implements Serializable {
    private String studentId;
    private String subject;
    private double marks;
    private String grade;
    
    // Constructor with all fields (used in your App.java)
    public MarkSheet(String studentId, String subject, double marks, String grade) {
        this.studentId = studentId;
        this.subject = subject;
        this.marks = marks;
        this.grade = grade;
    }
    
    // Additional constructor for compatibility (if needed elsewhere)
    public MarkSheet(String studentId, double marks, String grade) {
        this(studentId, "General", marks, grade);
    }
    
    // Default constructor for serialization
    public MarkSheet() {
        this("", "", 0.0, "");
    }
    
    // Getters
    public String getStudentId() { return studentId; }
    public String getSubject() { return subject; }
    public double getMarks() { return marks; }
    public String getGrade() { return grade; }
    
    // Setters
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setMarks(double marks) { this.marks = marks; }
    public void setGrade(String grade) { this.grade = grade; }
    
    @Override
    public String toString() {
        return "Student: " + studentId + " | Subject: " + subject + " | Marks: " + marks + " | Grade: " + grade;
    }
}