
package com.mycompany.schoolmanagementsystem.utils;


import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FileHandler {
    private static final String DATA_FILE = "school_data.ser";
    private static final String BACKUP_FILE = "school_data_backup.ser";
    
    // Save data to file
    public static void saveData(Object data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(data);
            System.out.println("Data saved successfully to " + DATA_FILE);
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Load data from file
    public static Object loadData() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            System.out.println("No saved data found. Starting with default data.");
            return null;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            Object data = ois.readObject();
            System.out.println("Data loaded successfully from " + DATA_FILE);
            return data;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
            return null;
        }
    }
    
    // Create backup
    public static void createBackup(Object data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(BACKUP_FILE))) {
            oos.writeObject(data);
            System.out.println("Backup created successfully");
        } catch (IOException e) {
            System.err.println("Error creating backup: " + e.getMessage());
        }
    }
    
    // Restore from backup
    public static Object restoreFromBackup() {
        File file = new File(BACKUP_FILE);
        if (!file.exists()) {
            System.out.println("No backup file found");
            return null;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(BACKUP_FILE))) {
            Object data = ois.readObject();
            System.out.println("Backup restored successfully");
            return data;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error restoring backup: " + e.getMessage());
            return null;
        }
    }
    
    // Export student data to CSV
    public static void exportStudentsToCSV(java.util.List<com.mycompany.schoolmanagementsystem.models.Student> students, String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("ID,Name,Class,Phone");
            for (com.mycompany.schoolmanagementsystem.models.Student s : students) {
                writer.printf("%s,%s,%s,%s%n", s.getId(), s.getName(), s.getClassName(), s.getPhone());
            }
            System.out.println("Exported to " + filename);
        } catch (IOException e) {
            System.err.println("Error exporting to CSV: " + e.getMessage());
        }
    }
    
    // Export attendance report
    public static void exportAttendanceReport(java.util.List<com.mycompany.schoolmanagementsystem.models.Attendance> attendances, String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("Student ID,Date,Status");
            for (com.mycompany.schoolmanagementsystem.models.Attendance a : attendances) {
                writer.printf("%s,%s,%s%n", a.getStudentId(), a.getDate(), a.getStatus());
            }
            System.out.println("Attendance report exported to " + filename);
        } catch (IOException e) {
            System.err.println("Error exporting attendance: " + e.getMessage());
        }
    }
    
    // Clear all data
    public static void clearData() {
        File file = new File(DATA_FILE);
        if (file.exists()) {
            file.delete();
            System.out.println("Data cleared successfully");
        }
    }
}