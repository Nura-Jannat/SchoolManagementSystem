
package com.mycompany.schoolmanagementsystem.ui;
import com.mycompany.schoolmanagementsystem.models.Student;
import com.mycompany.schoolmanagementsystem.models.Teacher;
import java.util.List;

public class SearchResult {
    private String query;
    private List<Object> results;
    private long searchTime;
    private int resultCount;
    
    public SearchResult(String query, List<Object> results, long searchTime) {
        this.query = query;
        this.results = results;
        this.searchTime = searchTime;
        this.resultCount = results.size();
    }
    
    public String getQuery() { return query; }
    public List<Object> getResults() { return results; }
    public long getSearchTime() { return searchTime; }
    public int getResultCount() { return resultCount; }
    
    public void setQuery(String query) { this.query = query; }
    public void setResults(List<Object> results) { 
        this.results = results;
        this.resultCount = results.size();
    }
    public void setSearchTime(long searchTime) { this.searchTime = searchTime; }
    
    public String getFormattedResults() {
        StringBuilder sb = new StringBuilder();
        sb.append("Search Results for: '").append(query).append("'\n");
        sb.append("Found ").append(resultCount).append(" results in ").append(searchTime).append("ms\n");
        sb.append("─".repeat(50)).append("\n");
        
        for (Object obj : results) {
            if (obj instanceof Student) {
                Student s = (Student) obj;
                sb.append("📚 STUDENT: ").append(s.getInfo()).append("\n");
                if (s.getAcademicRecord() != null) {
                    sb.append("   📊 Academic: ").append(s.getAcademicRecord()).append("\n");
                }
            } else if (obj instanceof Teacher) {
                Teacher t = (Teacher) obj;
                sb.append("👨‍🏫 TEACHER: ").append(t.getInfo()).append("\n");
            }
            sb.append("\n");
        }
        
        return sb.toString();
    }
    
    public String getSummary() {
        return String.format("Search '%s' returned %d results", query, resultCount);
    }
    
    public boolean hasResults() {
        return resultCount > 0;
    }
    
    public Student getFirstStudentResult() {
        for (Object obj : results) {
            if (obj instanceof Student) {
                return (Student) obj;
            }
        }
        return null;
    }
    
    public Teacher getFirstTeacherResult() {
        for (Object obj : results) {
            if (obj instanceof Teacher) {
                return (Teacher) obj;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return getFormattedResults();
    }
}
