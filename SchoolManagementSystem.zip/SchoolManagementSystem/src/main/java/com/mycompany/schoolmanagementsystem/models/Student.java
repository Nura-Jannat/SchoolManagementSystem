package com.mycompany.schoolmanagementsystem.models;


import java.io.Serializable;

public class Student extends Person implements Serializable {
    private String className;
    private String phone;
    private AcademicRecord academicRecord;
    
    public Student(String name, String id, String className, String phone) {
        super(name, id);
        this.className = className;
        this.phone = phone;
    }
    
    @Override
    public String getInfo() {
        return "ID: " + id + " | Name: " + name + " | Class: " + className + " | Phone: " + phone;
    }
    
    public String getClassName() { return className; }
    public String getPhone() { return phone; }
    public AcademicRecord getAcademicRecord() { return academicRecord; }
    
    public void setClassName(String className) { this.className = className; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setAcademicRecord(AcademicRecord academicRecord) { this.academicRecord = academicRecord; }
}