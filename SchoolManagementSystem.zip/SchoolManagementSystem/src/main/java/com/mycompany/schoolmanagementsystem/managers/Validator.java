
package com.mycompany.schoolmanagementsystem.managers;


import com.mycompany.schoolmanagementsystem.models.Student;
import java.util.List;
import java.util.regex.Pattern;

public class Validator {
    
    // Validate Student ID (alphanumeric, 4-10 characters)
    public static boolean validateID(String id) {
        if (id == null || id.isEmpty()) {
            return false;
        }
        Pattern pattern = Pattern.compile("^[A-Za-z0-9]{4,10}$");
        return pattern.matcher(id).matches();
    }
    
    // Validate Name (only letters and spaces, 2-50 characters)
    public static boolean validateName(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }
        Pattern pattern = Pattern.compile("^[A-Za-z\\s]{2,50}$");
        return pattern.matcher(name).matches();
    }
    
    // Validate Phone Number (10-15 digits, optional + prefix)
    public static boolean validatePhone(String phone) {
        if (phone == null || phone.isEmpty()) {
            return true; // Phone is optional
        }
        Pattern pattern = Pattern.compile("^\\+?[0-9]{10,15}$");
        return pattern.matcher(phone).matches();
    }
    
    // Validate Class Name (e.g., 10-A, 12-B)
    public static boolean validateClassName(String className) {
        if (className == null || className.isEmpty()) {
            return false;
        }
        Pattern pattern = Pattern.compile("^[0-9]{1,2}-[A-Z]$");
        return pattern.matcher(className).matches();
    }
    
    // Validate Marks (0-100)
    public static boolean validateMarks(double marks) {
        return marks >= 0 && marks <= 100;
    }
    
    // Check for duplicate ID in student list
    public static boolean checkDuplicateID(List<Student> students, String id) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }
    
    // Validate Email format
    public static boolean validateEmail(String email) {
        if (email == null || email.isEmpty()) {
            return true; // Email is optional
        }
        Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
        return pattern.matcher(email).matches();
    }
    
    // Validate Salary (positive number)
    public static boolean validateSalary(double salary) {
        return salary > 0;
    }
}