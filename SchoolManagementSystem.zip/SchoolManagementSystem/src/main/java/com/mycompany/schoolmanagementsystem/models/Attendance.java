
package com.mycompany.schoolmanagementsystem.models;


import java.io.Serializable;
import java.time.LocalDate;

public class Attendance implements Serializable {
    private String studentId;
    private LocalDate date;
    private String status;
    
    public Attendance(String studentId, LocalDate date, String status) {
        this.studentId = studentId;
        this.date = date;
        this.status = status;
    }
    
    public String getStudentId() { return studentId; }
    public LocalDate getDate() { return date; }
    public String getStatus() { return status; }
    
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public void setDate(LocalDate date) { this.date = date; }
    public void setStatus(String status) { this.status = status; }
}