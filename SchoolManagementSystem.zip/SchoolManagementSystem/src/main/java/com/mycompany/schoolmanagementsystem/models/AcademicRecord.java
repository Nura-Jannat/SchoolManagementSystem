package com.mycompany.schoolmanagementsystem.models;


import java.io.Serializable;

public class AcademicRecord implements Serializable {
    private String subject;
    private double marks;
    private String grade;
    
    public AcademicRecord(String subject, double marks, String grade) {
        this.subject = subject;
        this.marks = marks;
        this.grade = grade;
    }
    
    public String getSubject() { return subject; }
    public double getMarks() { return marks; }
    public String getGrade() { return grade; }
    
    public void setSubject(String subject) { this.subject = subject; }
    public void setMarks(double marks) { this.marks = marks; }
    public void setGrade(String grade) { this.grade = grade; }
}