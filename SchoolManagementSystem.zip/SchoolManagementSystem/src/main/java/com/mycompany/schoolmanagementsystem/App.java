package com.mycompany.schoolmanagementsystem;

import com.mycompany.schoolmanagementsystem.managers.LoginManager;
import com.mycompany.schoolmanagementsystem.managers.SchoolManager;
import com.mycompany.schoolmanagementsystem.managers.Validator;
import com.mycompany.schoolmanagementsystem.models.*;
import com.mycompany.schoolmanagementsystem.utils.FileHandler;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

public class App extends Application {
    private SchoolManager manager;
    private LoginManager loginManager;
    private Stage primaryStage;
    private Stage loginStage;

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        manager = new SchoolManager();
        loginManager = new LoginManager();
        
        // Load saved data
        loadData();
        
        // Show login screen
        showLoginScreen();
    }
    
    private void showLoginScreen() {
        loginStage = new Stage();
        loginStage.setTitle("School Management System - Login");
        
        VBox loginBox = new VBox(15);
        loginBox.setAlignment(Pos.CENTER);
        loginBox.setPadding(new Insets(40));
        loginBox.setStyle("-fx-background-color: linear-gradient(to bottom, #2c3e50, #3498db);");
        
        Label titleLabel = new Label("Smart School Management System");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: white;");
        
        Label subtitleLabel = new Label("Please Login to Continue");
        subtitleLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #ecf0f1;");
        
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setStyle("-fx-font-size: 14px; -fx-pref-width: 250px;");
        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setStyle("-fx-font-size: 14px; -fx-pref-width: 250px;");
        
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-pref-width: 250px;");
        
        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: #e74c3c;");
        
        loginButton.setOnAction(e -> {
            if (loginManager.login(usernameField.getText(), passwordField.getText())) {
                loginStage.close();
                showMainDashboard();
            } else {
                messageLabel.setText("Invalid username or password! (Use: admin / admin123)");
            }
        });
        
        loginBox.getChildren().addAll(titleLabel, subtitleLabel, usernameField, passwordField, loginButton, messageLabel);
        
        Scene loginScene = new Scene(loginBox, 500, 400);
        loginStage.setScene(loginScene);
        loginStage.show();
    }
    
    private void showMainDashboard() {
        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #f4f6f9;");
        
        // Header
        HBox header = createHeader();
        mainLayout.setTop(header);
        
        // Sidebar
        VBox sidebar = createSidebar();
        mainLayout.setLeft(sidebar);
        
        // Center content
        StackPane centerContent = new StackPane();
        centerContent.setPadding(new Insets(20));
        mainLayout.setCenter(centerContent);
        
        // Default view - Student List
        showStudentList(centerContent);
        
        Scene scene = new Scene(mainLayout, 1200, 700);
        primaryStage.setTitle("Smart School Management System");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        // Sidebar button actions
        setupSidebarActions(sidebar, centerContent);
    }
    
    private HBox createHeader() {
        HBox header = new HBox(15);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(15, 20, 15, 20));
        header.setStyle("-fx-background-color: #2c3e50;");
        
        Label titleLabel = new Label("🏫 Smart School Management System");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: white;");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        String currentUser = loginManager.getCurrentUser();
        Label userLabel = new Label("👤 " + (currentUser != null ? currentUser : "Guest"));
        userLabel.setStyle("-fx-text-fill: #ecf0f1; -fx-font-size: 14px;");
        
        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 12px;");
        logoutBtn.setOnAction(e -> {
            loginManager.logout();
            primaryStage.close();
            showLoginScreen();
        });
        
        header.getChildren().addAll(titleLabel, spacer, userLabel, logoutBtn);
        return header;
    }
    
    private VBox createSidebar() {
        VBox sidebar = new VBox(10);
        sidebar.setPadding(new Insets(20, 10, 20, 10));
        sidebar.setStyle("-fx-background-color: #34495e; -fx-pref-width: 200px;");
        
        String[] buttonLabels = {
            "📋 Student List", "➕ Add Student", "❌ Delete Student", "🔍 Search Student",
            "📝 Mark Attendance", "🎓 Academic Records", "👨‍🏫 Teachers", "📊 Dashboard"
        };
        
        for (String label : buttonLabels) {
            Button btn = new Button(label);
            btn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-alignment: CENTER_LEFT; -fx-pref-width: 180px; -fx-padding: 10;");
            btn.setOnMouseEntered(e -> btn.setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white; -fx-alignment: CENTER_LEFT; -fx-pref-width: 180px; -fx-padding: 10;"));
            btn.setOnMouseExited(e -> btn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-alignment: CENTER_LEFT; -fx-pref-width: 180px; -fx-padding: 10;"));
            sidebar.getChildren().add(btn);
        }
        
        return sidebar;
    }
    
    private void setupSidebarActions(VBox sidebar, StackPane centerContent) {
        for (int i = 0; i < sidebar.getChildren().size(); i++) {
            Button btn = (Button) sidebar.getChildren().get(i);
            switch (i) {
                case 0: btn.setOnAction(e -> showStudentList(centerContent)); break;
                case 1: btn.setOnAction(e -> showAddStudentForm(centerContent)); break;
                case 2: btn.setOnAction(e -> showDeleteStudentForm(centerContent)); break;
                case 3: btn.setOnAction(e -> showSearchStudentForm(centerContent)); break;
                case 4: btn.setOnAction(e -> showMarkAttendanceForm(centerContent)); break;
                case 5: btn.setOnAction(e -> showAcademicRecordForm(centerContent)); break;
                case 6: btn.setOnAction(e -> showTeacherList(centerContent)); break;
                case 7: btn.setOnAction(e -> showDashboard(centerContent)); break;
            }
        }
    }
    
    private void showStudentList(StackPane centerContent) {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Student List");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        TableView<Student> tableView = new TableView<>();
        tableView.setPrefHeight(500);
        
        TableColumn<Student, String> idCol = new TableColumn<>("Student ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(120);
        
        TableColumn<Student, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(150);
        
        TableColumn<Student, String> classCol = new TableColumn<>("Class");
        classCol.setCellValueFactory(new PropertyValueFactory<>("className"));
        classCol.setPrefWidth(100);
        
        TableColumn<Student, String> phoneCol = new TableColumn<>("Phone");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        phoneCol.setPrefWidth(120);
        
        TableColumn<Student, String> gradeCol = new TableColumn<>("Grade");
        gradeCol.setCellValueFactory(cellData -> {
            Student student = cellData.getValue();
            AcademicRecord record = student.getAcademicRecord();
            String grade = (record != null) ? record.getGrade() : "N/A";
            return new javafx.beans.property.SimpleStringProperty(grade);
        });
        gradeCol.setPrefWidth(80);
        
        tableView.getColumns().addAll(idCol, nameCol, classCol, phoneCol, gradeCol);
        
        List<Student> studentList = manager.getAllStudents();
        if (studentList != null && !studentList.isEmpty()) {
            tableView.setItems(FXCollections.observableArrayList(studentList));
        } else {
            tableView.setItems(FXCollections.observableArrayList());
            Label placeholder = new Label("No students found. Click 'Add Student' to add one.");
            placeholder.setStyle("-fx-text-fill: #7f8c8d; -fx-font-size: 14px;");
            tableView.setPlaceholder(placeholder);
        }
        
        Button refreshBtn = new Button("🔄 Refresh");
        refreshBtn.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");
        refreshBtn.setOnAction(e -> {
            tableView.setItems(FXCollections.observableArrayList(manager.getAllStudents()));
            tableView.refresh();
        });
        
        HBox buttonBar = new HBox(10);
        buttonBar.setAlignment(Pos.CENTER_RIGHT);
        buttonBar.getChildren().add(refreshBtn);
        
        content.getChildren().addAll(title, tableView, buttonBar);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    private void showAddStudentForm(StackPane centerContent) {
        VBox form = new VBox(15);
        form.setPadding(new Insets(30));
        form.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");
        form.setMaxWidth(500);
        
        Label title = new Label("Add New Student");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        TextField nameField = createStyledTextField("Full Name");
        TextField idField = createStyledTextField("Student ID (e.g., S001)");
        TextField classField = createStyledTextField("Class (e.g., 10-A)");
        TextField phoneField = createStyledTextField("Phone Number");
        
        Button submitBtn = new Button("Add Student");
        submitBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10;");
        
        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: #27ae60;");
        
        submitBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String id = idField.getText().trim().toUpperCase();
            String className = classField.getText().trim();
            String phone = phoneField.getText().trim();
            
            if (name.isEmpty() || id.isEmpty() || className.isEmpty()) {
                messageLabel.setText("Please fill all required fields!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                return;
            }
            
            if (!Validator.validateID(id)) {
                messageLabel.setText("ID must be 4-10 alphanumeric characters!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                return;
            }
            
            if (Validator.checkDuplicateID(manager.getAllStudents(), id)) {
                messageLabel.setText("Student ID already exists!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                return;
            }
            
            Student student = new Student(name, id, className, phone);
            manager.addStudent(student);
            messageLabel.setText("✓ Student added successfully!");
            messageLabel.setStyle("-fx-text-fill: #27ae60;");
            nameField.clear();
            idField.clear();
            classField.clear();
            phoneField.clear();
            saveData();
            refreshCurrentView(centerContent);
        });
        
        Button backBtn = new Button("← Back to Student List");
        backBtn.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px;");
        backBtn.setOnAction(e -> showStudentList(centerContent));
        
        form.getChildren().addAll(title, nameField, idField, classField, phoneField, submitBtn, backBtn, messageLabel);
        
        ScrollPane scrollPane = new ScrollPane(form);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        
        centerContent.getChildren().clear();
        centerContent.getChildren().add(scrollPane);
    }
    
    private void showDeleteStudentForm(StackPane centerContent) {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Delete Student");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        ComboBox<String> studentCombo = new ComboBox<>();
        studentCombo.setPromptText("Select Student");
        studentCombo.setStyle("-fx-font-size: 14px; -fx-pref-width: 300px;");
        
        refreshStudentCombo(studentCombo);
        
        Button deleteBtn = new Button("Delete Student");
        deleteBtn.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px;");
        
        Label messageLabel = new Label();
        
        deleteBtn.setOnAction(e -> {
            String selected = studentCombo.getValue();
            if (selected != null && !selected.equals("No students available")) {
                String id = selected.split(" - ")[0];
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, 
                    "Are you sure you want to delete " + selected + "?", 
                    ButtonType.YES, ButtonType.NO);
                confirm.showAndWait().ifPresent(response -> {
                    if (response == ButtonType.YES) {
                        manager.deleteStudent(id);
                        messageLabel.setText("✓ Student deleted successfully!");
                        messageLabel.setStyle("-fx-text-fill: #27ae60;");
                        refreshStudentCombo(studentCombo);
                        saveData();
                        refreshCurrentView(centerContent);
                    }
                });
            } else {
                messageLabel.setText("Please select a student!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
            }
        });
        
        Button backBtn = new Button("← Back to Student List");
        backBtn.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px;");
        backBtn.setOnAction(e -> showStudentList(centerContent));
        
        content.getChildren().addAll(title, studentCombo, deleteBtn, backBtn, messageLabel);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    private void showSearchStudentForm(StackPane centerContent) {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Search Student");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        TextField searchField = createStyledTextField("Enter Student ID or Name");
        searchField.setPrefWidth(400);
        
        Button searchBtn = new Button("Search");
        searchBtn.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");
        
        TextArea resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefHeight(300);
        resultArea.setStyle("-fx-font-size: 14px;");
        
        searchBtn.setOnAction(e -> {
            String query = searchField.getText().trim();
            if (query.isEmpty()) {
                resultArea.setText("Please enter a search query.");
                return;
            }
            
            List<Student> results = manager.searchStudents(query);
            if (results.isEmpty()) {
                resultArea.setText("No students found matching: " + query);
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Found ").append(results.size()).append(" result(s):\n\n");
                for (Student s : results) {
                    sb.append(s.getInfo()).append("\n");
                    if (s.getAcademicRecord() != null) {
                        sb.append("  📊 Subject: ").append(s.getAcademicRecord().getSubject()).append("\n");
                        sb.append("  📝 Marks: ").append(s.getAcademicRecord().getMarks()).append("\n");
                        sb.append("  🎓 Grade: ").append(s.getAcademicRecord().getGrade()).append("\n");
                    }
                    sb.append("  ─────────────────────\n\n");
                }
                resultArea.setText(sb.toString());
            }
        });
        
        Button clearBtn = new Button("Clear");
        clearBtn.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px;");
        clearBtn.setOnAction(e -> {
            searchField.clear();
            resultArea.clear();
        });
        
        HBox buttonBar = new HBox(10);
        buttonBar.getChildren().addAll(searchBtn, clearBtn);
        
        content.getChildren().addAll(title, searchField, buttonBar, resultArea);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    private void showMarkAttendanceForm(StackPane centerContent) {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Mark Attendance");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        ComboBox<String> studentCombo = new ComboBox<>();
        studentCombo.setPromptText("Select Student");
        studentCombo.setStyle("-fx-font-size: 14px; -fx-pref-width: 300px;");
        
        refreshStudentCombo(studentCombo);
        
        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setPromptText("Select Date");
        datePicker.setStyle("-fx-font-size: 14px;");
        
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Present", "Absent", "Late");
        statusCombo.setValue("Present");
        statusCombo.setStyle("-fx-font-size: 14px;");
        
        Button submitBtn = new Button("Mark Attendance");
        submitBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px;");
        
        Label messageLabel = new Label();
        
        submitBtn.setOnAction(e -> {
            String selected = studentCombo.getValue();
            if (selected != null && !selected.equals("No students available") && datePicker.getValue() != null) {
                String studentId = selected.split(" - ")[0];
                Attendance attendance = new Attendance(studentId, datePicker.getValue(), statusCombo.getValue());
                manager.addAttendance(attendance);
                messageLabel.setText("✓ Attendance marked successfully!");
                messageLabel.setStyle("-fx-text-fill: #27ae60;");
                saveData();
            } else {
                messageLabel.setText("Please select student and date!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
            }
        });
        
        content.getChildren().addAll(title, studentCombo, datePicker, statusCombo, submitBtn, messageLabel);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    // FIXED: Academic Record Form with correct MarkSheet constructor
    private void showAcademicRecordForm(StackPane centerContent) {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Add Academic Record");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        ComboBox<String> studentCombo = new ComboBox<>();
        studentCombo.setPromptText("Select Student");
        studentCombo.setStyle("-fx-font-size: 14px; -fx-pref-width: 300px;");
        
        refreshStudentCombo(studentCombo);
        
        TextField subjectField = createStyledTextField("Subject");
        TextField marksField = createStyledTextField("Marks (0-100)");
        
        Button submitBtn = new Button("Add Record");
        submitBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px;");
        
        Label messageLabel = new Label();
        
        submitBtn.setOnAction(e -> {
            String selected = studentCombo.getValue();
            if (selected != null && !selected.equals("No students available") && 
                !subjectField.getText().trim().isEmpty() && 
                !marksField.getText().trim().isEmpty()) {
                try {
                    double marks = Double.parseDouble(marksField.getText().trim());
                    if (marks < 0 || marks > 100) {
                        messageLabel.setText("Marks must be between 0 and 100!");
                        messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                        return;
                    }
                    
                    String studentId = selected.split(" - ")[0];
                    Student student = manager.findStudentById(studentId);
                    String subject = subjectField.getText().trim();
                    
                    if (student != null) {
                        String grade = calculateGrade(marks);
                        AcademicRecord record = new AcademicRecord(subject, marks, grade);
                        student.setAcademicRecord(record);
                        
                        // FIXED: Creating MarkSheet with 4 parameters (studentId, subject, marks, grade)
                        MarkSheet markSheet = new MarkSheet(studentId, subject, marks, grade);
                        manager.addMarkSheet(markSheet);
                        
                        messageLabel.setText("✓ Academic record added! Grade: " + grade);
                        messageLabel.setStyle("-fx-text-fill: #27ae60;");
                        subjectField.clear();
                        marksField.clear();
                        saveData();
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid marks! Please enter a number.");
                    messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                }
            } else {
                messageLabel.setText("Please fill all fields!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
            }
        });
        
        Button backBtn = new Button("← Back");
        backBtn.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px;");
        backBtn.setOnAction(e -> showStudentList(centerContent));
        
        content.getChildren().addAll(title, studentCombo, subjectField, marksField, submitBtn, backBtn, messageLabel);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    private void showTeacherList(StackPane centerContent) {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Teacher List");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        TableView<Teacher> tableView = new TableView<>();
        tableView.setPrefHeight(500);
        
        TableColumn<Teacher, String> idCol = new TableColumn<>("Teacher ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(120);
        
        TableColumn<Teacher, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(150);
        
        TableColumn<Teacher, String> subjectCol = new TableColumn<>("Subject");
        subjectCol.setCellValueFactory(new PropertyValueFactory<>("subject"));
        subjectCol.setPrefWidth(150);
        
        TableColumn<Teacher, String> phoneCol = new TableColumn<>("Phone");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        phoneCol.setPrefWidth(120);
        
        TableColumn<Teacher, Double> salaryCol = new TableColumn<>("Salary");
        salaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));
        salaryCol.setPrefWidth(100);
        
        tableView.getColumns().addAll(idCol, nameCol, subjectCol, phoneCol, salaryCol);
        
        if (manager.getAllTeachers().isEmpty()) {
            manager.addTeacher(new Teacher("Dr. Smith", "T001", "Mathematics", "555-0101", 50000));
            manager.addTeacher(new Teacher("Prof. Johnson", "T002", "Physics", "555-0102", 52000));
            manager.addTeacher(new Teacher("Ms. Davis", "T003", "English", "555-0103", 48000));
            saveData();
        }
        
        tableView.setItems(FXCollections.observableArrayList(manager.getAllTeachers()));
        
        Button addTeacherBtn = new Button("+ Add New Teacher");
        addTeacherBtn.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");
        addTeacherBtn.setOnAction(e -> showAddTeacherForm(centerContent));
        
        Button refreshBtn = new Button("🔄 Refresh");
        refreshBtn.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px;");
        refreshBtn.setOnAction(e -> {
            tableView.setItems(FXCollections.observableArrayList(manager.getAllTeachers()));
            tableView.refresh();
        });
        
        HBox buttonBar = new HBox(10);
        buttonBar.setAlignment(Pos.CENTER_RIGHT);
        buttonBar.getChildren().addAll(addTeacherBtn, refreshBtn);
        
        content.getChildren().addAll(title, tableView, buttonBar);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    private void showAddTeacherForm(StackPane centerContent) {
        VBox form = new VBox(15);
        form.setPadding(new Insets(30));
        form.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");
        form.setMaxWidth(500);
        
        Label title = new Label("Add New Teacher");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        TextField nameField = createStyledTextField("Full Name");
        TextField idField = createStyledTextField("Teacher ID (e.g., T001)");
        TextField subjectField = createStyledTextField("Subject");
        TextField phoneField = createStyledTextField("Phone Number");
        TextField salaryField = createStyledTextField("Salary");
        
        Button submitBtn = new Button("Add Teacher");
        submitBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10;");
        
        Label messageLabel = new Label();
        
        submitBtn.setOnAction(e -> {
            try {
                String name = nameField.getText().trim();
                String id = idField.getText().trim().toUpperCase();
                String subject = subjectField.getText().trim();
                String phone = phoneField.getText().trim();
                double salary = Double.parseDouble(salaryField.getText().trim());
                
                if (name.isEmpty() || id.isEmpty() || subject.isEmpty()) {
                    messageLabel.setText("Please fill all required fields!");
                    messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                    return;
                }
                
                if (salary <= 0) {
                    messageLabel.setText("Salary must be greater than 0!");
                    messageLabel.setStyle("-fx-text-fill: #e74c3c;");
                    return;
                }
                
                Teacher teacher = new Teacher(name, id, subject, phone, salary);
                manager.addTeacher(teacher);
                messageLabel.setText("✓ Teacher added successfully!");
                messageLabel.setStyle("-fx-text-fill: #27ae60;");
                nameField.clear();
                idField.clear();
                subjectField.clear();
                phoneField.clear();
                salaryField.clear();
                saveData();
            } catch (NumberFormatException ex) {
                messageLabel.setText("Please enter a valid salary amount!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
            } catch (Exception ex) {
                messageLabel.setText("Please fill all fields correctly!");
                messageLabel.setStyle("-fx-text-fill: #e74c3c;");
            }
        });
        
        Button backBtn = new Button("← Back to Teacher List");
        backBtn.setStyle("-fx-background-color: #95a5a6; -fx-text-fill: white; -fx-font-size: 14px;");
        backBtn.setOnAction(e -> showTeacherList(centerContent));
        
        form.getChildren().addAll(title, nameField, idField, subjectField, phoneField, salaryField, submitBtn, backBtn, messageLabel);
        
        ScrollPane scrollPane = new ScrollPane(form);
        scrollPane.setFitToWidth(true);
        
        centerContent.getChildren().clear();
        centerContent.getChildren().add(scrollPane);
    }
    
    private void showDashboard(StackPane centerContent) {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        
        Label title = new Label("Dashboard");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        GridPane statsGrid = new GridPane();
        statsGrid.setHgap(20);
        statsGrid.setVgap(20);
        statsGrid.setAlignment(Pos.CENTER);
        
        int studentCount = manager.getAllStudents().size();
        int teacherCount = manager.getAllTeachers().size();
        int attendanceCount = manager.getAllAttendances().size();
        int markSheetCount = manager.getAllMarkSheets().size();
        
        VBox studentCard = createStatCard("👨‍🎓 Students", String.valueOf(studentCount), "#3498db");
        VBox teacherCard = createStatCard("👨‍🏫 Teachers", String.valueOf(teacherCount), "#e74c3c");
        VBox attendanceCard = createStatCard("📋 Attendance", String.valueOf(attendanceCount), "#27ae60");
        VBox marksCard = createStatCard("📝 Records", String.valueOf(markSheetCount), "#f39c12");
        
        statsGrid.add(studentCard, 0, 0);
        statsGrid.add(teacherCard, 1, 0);
        statsGrid.add(attendanceCard, 2, 0);
        statsGrid.add(marksCard, 3, 0);
        
        Label recentLabel = new Label("Recent Activity");
        recentLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        ListView<String> activityList = new ListView<>();
        activityList.setPrefHeight(200);
        activityList.getItems().addAll(
            "✓ System initialized successfully",
            "✓ " + studentCount + " students registered",
            "✓ " + teacherCount + " teachers on staff",
            "✓ " + attendanceCount + " attendance records",
            "✓ " + markSheetCount + " academic records",
            "✓ System ready for use"
        );
        
        Button refreshDashboardBtn = new Button("🔄 Refresh Dashboard");
        refreshDashboardBtn.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");
        refreshDashboardBtn.setOnAction(e -> showDashboard(centerContent));
        
        content.getChildren().addAll(title, statsGrid, recentLabel, activityList, refreshDashboardBtn);
        centerContent.getChildren().clear();
        centerContent.getChildren().add(content);
    }
    
    private VBox createStatCard(String title, String value, String color) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 10; -fx-min-width: 160px;");
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px;");
        
        Label valueLabel = new Label(value);
        valueLabel.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
        
        card.getChildren().addAll(titleLabel, valueLabel);
        return card;
    }
    
    private TextField createStyledTextField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-radius: 5;");
        return field;
    }
    
    private void refreshStudentCombo(ComboBox<String> combo) {
        combo.getItems().clear();
        List<Student> students = manager.getAllStudents();
        if (students != null && !students.isEmpty()) {
            combo.setDisable(false);
            for (Student s : students) {
                combo.getItems().add(s.getId() + " - " + s.getName());
            }
        } else {
            combo.getItems().add("No students available");
            combo.setDisable(true);
        }
    }
    
    private void refreshCurrentView(StackPane centerContent) {
        showStudentList(centerContent);
    }
    
    private String calculateGrade(double marks) {
        if (marks >= 90) return "A+";
        if (marks >= 80) return "A";
        if (marks >= 70) return "B+";
        if (marks >= 60) return "B";
        if (marks >= 50) return "C";
        if (marks >= 40) return "D";
        return "F";
    }
    
    private void saveData() {
        FileHandler.saveData(manager);
    }
    
    private void loadData() {
        SchoolManager loaded = (SchoolManager) FileHandler.loadData();
        if (loaded != null) {
            manager = loaded;
        }
    }
}