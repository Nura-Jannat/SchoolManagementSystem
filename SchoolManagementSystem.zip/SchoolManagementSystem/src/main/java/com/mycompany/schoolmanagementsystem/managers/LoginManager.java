
package com.mycompany.schoolmanagementsystem.managers;



import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class LoginManager implements Serializable {
    private Map<String, String> userCredentials;
    private String currentUser;
    
    public LoginManager() {
        userCredentials = new HashMap<>();
        // Default admin credentials
        userCredentials.put("admin", "admin123");
        userCredentials.put("teacher", "teacher123");
        userCredentials.put("principal", "principal123");
        currentUser = null;
    }
    
    public boolean login(String username, String password) {
        if (userCredentials.containsKey(username) && userCredentials.get(username).equals(password)) {
            currentUser = username;
            return true;
        }
        return false;
    }
    
    public void logout() {
        currentUser = null;
    }
    
    public boolean isLoggedIn() {
        return currentUser != null;
    }
    
    public String getCurrentUser() {
        return currentUser;
    }
    
    public boolean changePassword(String username, String oldPassword, String newPassword) {
        if (userCredentials.containsKey(username) && userCredentials.get(username).equals(oldPassword)) {
            userCredentials.put(username, newPassword);
            return true;
        }
        return false;
    }
    
    public boolean addUser(String username, String password) {
        if (!userCredentials.containsKey(username)) {
            userCredentials.put(username, password);
            return true;
        }
        return false;
    }
    
    public boolean removeUser(String username) {
        if (userCredentials.containsKey(username) && !username.equals("admin")) {
            userCredentials.remove(username);
            return true;
        }
        return false;
    }
}