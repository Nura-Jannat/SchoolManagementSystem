module com.mycompany.schoolmanagementsystem {
    requires javafx.controls;
    exports com.mycompany.schoolmanagementsystem;
}
